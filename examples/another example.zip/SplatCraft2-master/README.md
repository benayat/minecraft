# SplatCraft 2
Use the arrow keys to move. Click blocks to place or break them. To change your block, go to the console and set currentBlock to a number 0 through 6. Thanks to ScratchTutorials for the "snap-to-grid" math. Other than that, everything is coded by me.
